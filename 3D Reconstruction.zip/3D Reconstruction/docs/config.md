# Configuration

**Page under construction...**

::: deep_image_matching.config.Config
    options:
      show_root_heading: true
      show_source: false
      members:

