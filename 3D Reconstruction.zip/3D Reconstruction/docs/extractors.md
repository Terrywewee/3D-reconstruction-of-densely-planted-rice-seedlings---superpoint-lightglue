# Extractors

**Page under construction...**

::: deep_image_matching.extractors.extractor_base.ExtractorBase
    options:
      show_root_heading: true
      show_source: false
      members:
        - __init__
        - extract
        - _extract
        - _extract_by_tile
        - _resize_image
        - _resize_features
        - viz_keypoints